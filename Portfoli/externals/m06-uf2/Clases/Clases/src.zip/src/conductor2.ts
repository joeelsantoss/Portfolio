export default class Conductor {
  private _nom:  string;
  private _dataNaixement: Date;
  private _potPortarMoto: boolean;

  constructor(nom: string, dataNaixement: Date, potPortarMoto: boolean) {
    this._nom = nom;
    this._potPortarMoto = potPortarMoto;
    
    // Validar edat abans d'assignar
    const edat = this.calcularEdat(dataNaixement);
    if (edat < 18) {
      throw new Error("El conductor ha de tenir almenys 18 anys");
    }
    this._dataNaixement = dataNaixement;
  }

  // Getter i setter per nom
  get Nom(): string {
    return this._nom;
  }

  set Nom(nom:  string) {
    this._nom = nom;
  }

  // Getter i setter per dataNaixement (amb validació d'edat)
  get DataNaixement(): Date {
    return this._dataNaixement;
  }

  set DataNaixement(data: Date) {
    const edat = this. calcularEdat(data);
    if (edat < 18) {
      throw new Error("El conductor ha de tenir almenys 18 anys");
    }
    this._dataNaixement = data;
  }

  // Getter i setter per potPortarMoto
  get potPortarMoto(): boolean {
    return this._potPortarMoto;
  }

  set potPortarMoto(valor: boolean) {
    this._potPortarMoto = valor;
  }

  // Mètode auxiliar per calcular l'edat
  private calcularEdat(dataNaixement: Date): number {
    const avui = new Date();
    let edat = avui.getFullYear() - dataNaixement.getFullYear();
    const mes = avui.getMonth() - dataNaixement.getMonth();
    
    // Ajustar si encara no ha complert anys aquest any
    if (mes < 0 || (mes === 0 && avui.getDate() < dataNaixement.getDate())) {
      edat--;
    }
    
    return edat;
  }

  // Mètode print amb paràmetre opcional
  print(modificador?: string | Date | boolean): string {
    let nom = this._nom;
    let edat = this. calcularEdat(this._dataNaixement);
    let moto = this._potPortarMoto ?  "Sí" : "No";

    // Modificar segons el paràmetre passat
    if (typeof modificador === "string") {
      nom = modificador;
    } else if (modificador instanceof Date) {
      edat = this.calcularEdat(modificador);
    } else if (typeof modificador === "boolean") {
      moto = modificador ? "Sí" : "No";
    }

    return `Nom: ${nom}, Edat: ${edat}, Pot portar moto: ${moto}`;
  }
}